$('.navi > li').mouseover(function(){
    $(this).find('.sub').stop().slideDown(200)
});

$('.navi > li').mouseout(function(){
    $(this).find('.sub').stop().slideUp(200)
});

$('.slide a:gt(0)').hide();
setInterval(function(){
    $('.slide a:first-child').fadeOut()
    .next('a').fadeIn()
    .end().appendTo('.slide');
},3000);